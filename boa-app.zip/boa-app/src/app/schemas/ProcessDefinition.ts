export class ProcessDefinition {
  id: string;
  name: string;
  key: string;
}
