module.exports = {
  script: './dist/client.js',
  style: './client/style.css',
  name: 'excel-import-plugin',
  menu: './menu.js'
};
