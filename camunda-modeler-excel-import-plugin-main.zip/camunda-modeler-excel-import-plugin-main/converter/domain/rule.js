export default (id, description, inputEntries, outputEntries) => {
  return {
    id: id,
    description: description,
    inputEntries: inputEntries,
    outputEntries: outputEntries
  };
};