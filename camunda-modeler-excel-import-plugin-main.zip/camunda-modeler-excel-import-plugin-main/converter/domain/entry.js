export default (id, text) => {
  return {
    id: id,
    text: text
  };
};