export default (content) => {
  return {
    content: content
  };
};