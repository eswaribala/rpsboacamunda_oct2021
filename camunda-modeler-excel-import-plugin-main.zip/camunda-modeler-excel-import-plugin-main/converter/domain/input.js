export default (id, label, inputExpression) => {
  return {
    id: id,
    label: label,
    inputExpression: inputExpression
  };
};