import { registerClientExtension } from 'camunda-modeler-plugin-helpers';

import ExcelPlugin from './ExcelPlugin';

registerClientExtension(ExcelPlugin);
